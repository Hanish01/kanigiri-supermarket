
function Kangira() {
    return (
      <div className="header">
        <h1>Kanigiri</h1>
        <img src="/logo.png" alt="No Img" />
        <h1>SuperMarket</h1>
      </div>
    );
}
export  default Kangira